import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!");

//        imperative way to calculate the sum of e pair numbers in 1 - 100

        int sumOfEvens = 0;

        for(int i = 0; i <= 100; i++){
            if(i % 2 == 0){
                sumOfEvens += i;
            }
        }
        System.out.println("imperative total: " + sumOfEvens);


        //    ================ DECLARATIVE WAY ============================

//        declarative is multi-thread safe, because we dont change var
//        in the imperative way we need to change a class scope var sumOfEvens
//        which can cause multi-threat problems

        int declarativeResult = IntStream.rangeClosed(0,100)
                .filter(i -> i % 2 == 0)
                .reduce((x,y) -> x+y)
                .getAsInt();

        System.out.println("declarative total: " + declarativeResult);
    }

}