package org.example.consumer.service;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ConsumerExerciseServiceTest {

    public ConsumerExerciseService consumerExerciseService = new ConsumerExerciseService();

    @Test
    public void testConsumer(){
        consumerExerciseService.get();
    }
}
