package org.example.consumer.service;

import java.util.function.Consumer;

public class ConsumerExerciseService {

    PrintWithPreText multipyMethodClass = new PrintWithPreText();

    public void get(){
        //Consumer<String> consumer = multipyMethodClass::doit;
    }
}
