package org.example.consumer.service;

public class PrintWithPreText {

    public void doit(int myString) {
        System.out.println("printed item: " + myString);
    }

}
