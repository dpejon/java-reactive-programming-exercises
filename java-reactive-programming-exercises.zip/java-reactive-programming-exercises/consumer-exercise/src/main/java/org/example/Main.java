package org.example;

import org.example.consumer.service.PrintWithPreText;

import java.util.List;
import java.util.function.Consumer;


public class Main {
    public static void main(String[] args) {
        PrintWithPreText printWithPreText = new PrintWithPreText();
        List<Integer> list = List.of(2,54,76,85,62,23,87);

//        method reference to object method
//        invokes a method from a object
//        you need to consume a method that uses the same params and return of your functional interface
        Consumer<Integer> consumer = printWithPreText::doit;

        consumer.accept(56);

        printElements(list, consumer);

    }

    private static <T> void printElements(List<T> list, Consumer<T> consumer){
        for(T item : list){
            consumer.accept(item);
        }
    }
}