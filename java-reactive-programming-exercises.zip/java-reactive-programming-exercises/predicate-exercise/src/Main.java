import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        System.out.println("Hello and welcome!");

//        given a String list with some blank values, return a new list wihout the empty values
//        the idea is use the predicate do validate a condition and create new list

        List<String> nameList = new ArrayList<>();
        nameList.add("");
        nameList.add("Daniel Pejon");
        nameList.add("");
        nameList.add("Lucas");
        nameList.add("Ajuanda");
        nameList.add("");

        Predicate<String> isNameEmpty = name -> name.isBlank();

        List<String> filteredList = filterList(nameList, isNameEmpty);

        for(String name : filteredList) {
            System.out.println("name: " + name);
        }

        }

    private static List<String> filterList(List<String> nameList, Predicate<String> isNameEmpty) {
        List<String> filteredList = new ArrayList<>();

        for(String name : nameList) {

            if(!isNameEmpty.test(name)) {
                filteredList.add(name);
            }

        }

        return filteredList;
    }

}