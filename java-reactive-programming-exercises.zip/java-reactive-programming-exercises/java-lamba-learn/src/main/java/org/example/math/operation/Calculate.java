package org.example.math.operation;

public interface Calculate {

    int operate (int num1, int num2);
}
