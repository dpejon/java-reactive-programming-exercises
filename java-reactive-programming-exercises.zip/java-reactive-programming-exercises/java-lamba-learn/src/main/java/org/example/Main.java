package org.example;

import org.example.math.operation.Calculate;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!");

//      Before the lambda we can use anonimous class declaration
//      this way create one new class in the bin everytime

        Calculate sum = new Calculate() {
            @Override
            public int operate(int num1, int num2) {
                return num1+num2;
            }
        };

        Calculate subs = new Calculate() {
            @Override
            public int operate(int num1, int num2) {
                return num1-num2;
            }
        };

        System.out.println("anonimous class Result sum: " + sum.operate(5,5));

//        after lamba we can use the method inside the funcional interface without need to create a new class
//        lambda is smart and dosent create new class files inside the bin
//        with lambda we can write the full code but lambda also nows the return type of the method so if you use just a simples line
//        you can just write the operation and lambda know this is the return
        Calculate lambdaSum = (p1,p2) -> {
            int i = p1+p2;
            return i;
        };

        Calculate lambdaDivide = (p1,p2) -> p1 / p2;

        System.out.println("lambda sum result: " + lambdaSum.operate(5,6));
    }
}